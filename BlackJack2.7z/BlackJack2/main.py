import random
values = [2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, "ace"]*4

random.shuffle(values)
black = "no"
player_hand = []
dealer_hand = []


def draw(hand):
    card = values.pop(0)
    hand.append(card)
    blackjack()
    return hand


def score():
    print("Dealer score: " + str(points(dealer_hand)))
    print("Your score: " + str(points(player_hand)))


def blackjack():
    d = (points(dealer_hand))
    p = (points(player_hand))
    global black
    if black == "no":
        if p == 21:
            print("You got blackjack, you won!")
            black = "yes"
            return black
        elif d == 21:
            print("Dealer got blackjack, you lost :(")
            black = "yes"
            return black
        elif d > 21:
            print("Dealer busted, you win!")
            black = "yes"
            return black
        elif p > 21:
            print("You busted, you lose")
            black = "yes"
            return black
        else:
            black = "no"
            return black


def count():
    global black
    d = (points(dealer_hand))
    p = (points(player_hand))
    if black == "no":
        if d > p:
            print("Dealer got more points than you, you lose")
        elif d == p:
            print("Draw")
        else:
            print("You got more points than dealer, you won!")
        black = "yes"
        return black


def points(hand):
    total = 0
    for card in hand:
        if card != "ace":
            total += card
        if card == "ace":
            if total <= 10:
                total += 11
            else:
                total += 1
    return total


def action():
    while black == "no":
        print("What would you like to do, draw, quit or stand?")
        b = input()
        if b == "quit":
            quit()
        elif b == "stand":
            while points(dealer_hand) < 17:
                draw(dealer_hand)
            score()
            count()
        elif b == "draw":
            draw(player_hand)
            if points(dealer_hand) < 17:
                draw(dealer_hand)
            score()
    print("End of the game")


def game():
    print("Welcome to Blackjack")
    print("Would you like to play?")
    a = input()
    if a == "yes" or a == "y":
        draw(dealer_hand)
        draw(player_hand) and draw(player_hand)
        score()
        action()
    else:
        quit()
    play_again()


def play_again():
    global values
    global black
    global player_hand
    global dealer_hand
    print("Would you like to play again?")
    o = input()
    if o == "yes" or o == "y":
        values = [2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, "ace"] * 4
        random.shuffle(values)
        black = "no"
        player_hand = []
        dealer_hand = []
        draw(dealer_hand)
        draw(player_hand) and draw(player_hand)
        score()
        action()
        play_again()
    else:
        quit()


game()
