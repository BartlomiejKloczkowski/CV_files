library(lubridate)
library(tidyverse)
library(corrplot)
library(Hmisc)
library(ggplot2) 
library(tseries)
rm(list = ls())
options(scipen=999)


########################################### PRZYGOTOWANIE DANYCH ###########################################
### LINK DO DANYCH: https://www.kaggle.com/datasets/dhruvildave/currency-exchange-rates
### LINK DO INSPIRACJI: https://www.mataf.net/en/forex/tools/correlation
df <- read.csv("forex.csv")

# Zmiana kolumn
df$open = (df$open + df$close) / 2
df <- subset(df, select = -c(high, low, currency, close))
colnames(df) <- c('CCY_PAIR', 'DATE', 'RATE') 

# Interesujące nas lata
years <- "2016|2017|2018|2019|2020"
df <- df[grep(years, df$DATE),]

# Drop problematycznych walut
df <- df[df$CCY_PAIR != "GBP/CUP",]

# Usuwa dni z brakami danych
for (ccy in unique(df$CCY_PAIR)) {
    if (length(df[df$CCY_PAIR == ccy,"DATE"]) < length(unique(df$DATE))) {
        missing_days = unique(df$DATE)[!unique(df$DATE) %in% df[df$CCY_PAIR == ccy,"DATE"]]
        for (day in missing_days) {
            df = df[df$DATE != day,]
        }
    }
}

# Reset indeksów
row.names(df) <- NULL

# Nowa kolumna: dzienna procentowa zmiana
df$PERCENT_CHANGE <- append(0, df$RATE)[-length(append(0, df$RATE))]
df$PERCENT_CHANGE <- (df$RATE/df$PERCENT_CHANGE - 1) * 100 

#Usunięcie wierszy bez porównania
df <- filter(df, DATE != min(df$DATE))

# Transformacja układu tabelki
a <- data.frame(matrix(nrow = length(unique(df$DATE)), ncol = length(c("DATE", unique(df$CCY_PAIR)))))
colnames(a) <- c("DATE", unique(df$CCY_PAIR))
a$DATE <- unique(df$DATE)
for (ccy in unique(df$CCY_PAIR)) {
    a[ccy] <- df[df$CCY_PAIR == ccy,"PERCENT_CHANGE"]   
}
df <- a #DF całości
df_corr <- subset(a, select = -DATE) #DF z wybranymi walutami bez daty
#df_corr_ALL <- subset(a, select = -DATE) #DF całości bez daty

# Wybór walut do dalszej analizy
worthy_currencies <- "EUR/USD|EUR/GBP|USD/GBP|EUR/PLN|USD/PLN|GBP/PLN"
df_corr <- select(df_corr, matches(worthy_currencies))


########################################### TESTY ###########################################
# Testy normalności
normalnosc = c()
for (ccy in colnames(df_corr)) {
    normalnosc = c(normalnosc, jarque.bera.test(df_corr[[ccy]])$p.value)   
}
normalnosc = data.frame(colnames(df_corr), normalnosc)
colnames(normalnosc) <- c("Para walutowa", "p-value testu Jarque-Bera")
### WNIOSKI: żaden z ciągów zmiany kursu walut nie pochodzi z rozkładu normalnego: koniecznie jest użycie korelacji spearmana

#Tabelka w girdExtra - Jarque-Berra
library(gridExtra)
library(grid)
normalnosc_tabela = gridExtra::tableGrob(normalnosc) 
png("normalnosc.png", width = 275, height = 150)
grid.draw(normalnosc_tabela)
dev.off()

# Test Flignera-Killeena
df_string <- df_corr %>% pivot_longer(cols = everything(), names_to = "Currency", values_to = "Change")
fligner.test(df_string$Change~as.factor(df_string$Currency), data = df_string)$p.value
### WNIOSKI: p-value < 0.05, conajmniej 2 kursy mają różne wariancje

#Tabelka w girdExtra - Flignera-Killeena
homogenicznosc = data.frame(kolumna1 = "Test Flignera-Killeena") #Tabelka w R
p_value_FK = round(fligner.test(Change ~ as.factor(Currency), data = df_string)$p.value)
homogenicznosc$kolumna2 = p_value_FK
colnames(homogenicznosc) = c("", "p-value")

homogenicznosc_tabela = gridExtra::tableGrob(homogenicznosc) 
png("homogenicznosc.png", width = 200, height = 42)
grid.draw(homogenicznosc_tabela)
dev.off()

# Założenia o normalnosci rozkładu i homogenicznosci wariancji nie sa spełnione - stosujemy test Kruskala-Wallisa
# Test Kruskala-Wallisa
kruskal.test(df_string$Change ~ as.factor(df_string$Currency))$p.value
### WNIOSKI: p-value > 0.05, kursy mają takie same średnie

#Tabelka w girdExtra - Kruskala-Wallisa
wariancja = data.frame(kolumna1 = "Test Kruskala-Wallisa") #Tabelka w R
p_value_KW = round(kruskal.test(df_string$Change ~ as.factor(df_string$Currency))$p.value, 4)
wariancja$kolumna2 = p_value_KW
colnames(wariancja) = c("", "p-value")

wariancja_tabela = gridExtra::tableGrob(wariancja) 
png("wariancja.png", width = 200, height = 42)
grid.draw(wariancja_tabela)
dev.off()

# Macierze
corr_matrix <- rcorr(as.matrix(df_corr), type = "spearman")$r
p_values <- rcorr(as.matrix(df_corr), type = "spearman")$P
#corr_matrix_ALL <- rcorr(as.matrix(df_corr_ALL), type = "spearman")$r
#p_values_ALL <- rcorr(as.matrix(df_corr_ALL), type = "spearman")$P


########################################### WYKRESY ###########################################
# Normalność
par(mfrow = c(2, 3))  
hist(df_corr$`EUR/USD`, main = "Histogram EUR/USD", xlab = "Change (%)", col = "navyblue")
hist(df_corr$`EUR/GBP`, main = "Histogram EUR/GBP", xlab = "Change (%)", col = "mediumseagreen")
hist(df_corr$`USD/GBP`, main = "Histogram USD/GBP", xlab = "Change (%)", col = "olivedrab1")
hist(df_corr$`EUR/PLN`, main = "Histogram EUR/PLN", xlab = "Change (%)", col = "orangered1")
hist(df_corr$`USD/PLN`, main = "Histogram USD/PLN", xlab = "Change (%)", col = "orange2")
hist(df_corr$`GBP/PLN`, main = "Histogram GBP/PLN", xlab = "Change (%)", col = "plum3")

#Propozycja Histogramów
ggplot(df_string, aes(x = Change, fill = Currency)) + 
  geom_histogram(color = "black") +  
  scale_fill_brewer(palette = "Set3") +  
  facet_wrap(~ Currency, scales = "free") +  
  labs(title = "Histogramy dla par walutowych",
       x = "Zmiana (%)",
       y = "Częstość") +
  theme_minimal() +  
  theme(legend.position = "none") 

# Macierz korelacji
palette = colorRampPalette(c("#2A3990", "gray91", "chocolate1")) (100)
par(mfrow = c(1, 1))
b = p_values
b[is.na(b)] <- 0
corrplot(corr_matrix, 
         type = "lower", 
         method = "square",
         order = "AOE", 
         p.mat = b, 
         sig.level = 0.05, 
         insig = "blank", 
         col = palette,
         tl.col = "black"
         )

#Propozycja  Macierz korelacji
library(ggcorrplot)
plt = ggcorrplot(corr_matrix,
           hc.order = TRUE,
           type = "lower",
           p.mat = p_values,
           lab = TRUE,
           colors = c("#2A3990", "gray91", "chocolate1"),
           outline.color = "black"
           )
plt
ggsave(plt,
       filename = "corrmatrix.png", 
       bg = "transparent"
)



library(sjPlot)
sjPlot::sjp.corr(df_corr,p.numeric = T, 
                 corr.method = "spearman", 
                 show.legend = T,
                 decimals = 2
                 
                 ) + 
  theme(text = element_text(size =15)) 

# Boxplot w podziale na waluty
boxplot(df_string$Change ~ df_string$Currency)

#Propozycja box-plot
ggplot(df_string, aes(x = Currency, y = Change, fill = Currency)) + 
  geom_boxplot() +
  scale_fill_brewer(palette = "Set3") +
  theme(legend.position = "none")

# Korelacja krzyżowa
# Robi wykresy wszystkich cross korelacji, jest ich 15
# Jeśli masz error 'plot.new()':figure margins too large trzeba powiększyć okienko z plots
# Wyrzucona jest korelacja z lag = 0, aby nie dominowało to wykresu
#Imo nic ciekawego z tej analizy nie wynika, nie wiem czy jest sens to dodawać, ale to zobaczymy czy 
#nie będzie nam brakowało paru minut
par(mfrow = c(4, 4))
for (x in 1:5) {
    for (y in (x+1):6) {
        a = ccf(
                df_corr[[x]], 
                df_corr[[y]],
                plot = FALSE
            )
        a$acf[ceiling(length(a$acf)/2)]=0
        plot(
            a,
            main = paste("Korelacja krzyżowa", colnames(df_corr)[x], "i", colnames(df_corr)[y])
        )
    }
}

# Pojedynczy wykres
par(mfrow = c(1, 1))
plt = ccf(df_corr[["USD/GBP"]], df_corr[["EUR/PLN"]], main = "Korelacja krzyżowa między USD/GBP i EUR/PLN")
ggsave(plot(plt, main = "Korelacja krzyżowa między USD/GBP i EUR/PLN"), 
       filename = "output.png", 
       bg = "transparent"
)


